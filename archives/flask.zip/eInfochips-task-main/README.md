# eInfochips-task
A website task in flask.
