import os

from flask import Flask, render_template, redirect, request, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin, login_user, LoginManager, login_required, logout_user, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, TextAreaField, BooleanField
from wtforms.validators import InputRequired, Length, ValidationError
from flask_bcrypt import Bcrypt
from flask_mail import *

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY']= 'thisisasecretkey'

app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'pansuriyashivam@gmail.com'
app.config['MAIL_PASSWORD'] = 'xnaoqldxrljxleeq'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True

db = SQLAlchemy(app)

bcrypt = Bcrypt(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

mail = Mail(app)


class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.Text, nullable=False)
    desc = db.Column(db.Text, nullable=False)
    img = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), nullable=False)
    onHome = db.Column(db.Boolean, default=False)

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), nullable=False, unique=True)
    password = db.Column(db.String(80), nullable=False)


class RegisterForm(FlaskForm):
    username = StringField(validators=[InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "Username"})
    password = PasswordField(validators=[InputRequired(), Length(min=8, max=20)], render_kw={"placeholder": "Password"})
    submit = SubmitField('Register')

    def validate_username(self, username):
        existing_user_username = User.query.filter_by(username=username.data).first()
        if existing_user_username:
            raise ValidationError('That username already exists. Please choose a different one.')

class LoginForm(FlaskForm):
    username = StringField(validators=[InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "Username"})
    password = PasswordField(validators=[InputRequired(), Length(min=8, max=20)], render_kw={"placeholder": "Password"})
    submit = SubmitField('Login')
    
class AddProduct(FlaskForm):
    name = StringField(validators=[InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "name"})
    desc = StringField(validators=[InputRequired(), Length(min=4, max=200)], render_kw={"placeholder": "desc"})
    img = StringField(validators=[InputRequired(), Length(min=4, max=2000)], render_kw={"placeholder": "img"})
    category = StringField(validators=[InputRequired(), Length(min=4, max=50)], render_kw={"placeholder": "category"})
    onHome = BooleanField('onHome')
    submit = SubmitField('Submit')

class ContactForm(FlaskForm):
    name = StringField(validators=[InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "Name"})
    email = StringField(validators=[InputRequired(), Length(min=4, max=200)], render_kw={"placeholder": "Email"})
    message = TextAreaField(validators=[InputRequired(), Length(min=4, max=2000)], render_kw={"placeholder": "Your Idea"})
    submit = SubmitField('Submit')


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def getAllCategories() -> list:
    all_products = Product.query.all()
    all_categories = set([x.category for x in all_products])
    all_categories = [x for x in all_categories]
    all_categories.sort()
    return all_categories

@app.route('/')
def home():
    all_products = Product.query.all()
    filtered_products = [x for x in all_products if x.onHome]
    all_categories = getAllCategories()
    return render_template('home.html', categories=all_categories, products=filtered_products)

@app.route('/products', methods=['POST'])
def products():
    if request.method == 'POST':
        category = request.form['products-category']
        filtered_products = Product.query.filter_by(category=category)
        all_categories = getAllCategories()
        return render_template('products.html', categories=all_categories, category=category, products=filtered_products)
    return redirect('/')

@app.route('/gallery')
def gallery():
    all_categories = getAllCategories()

    album_names = os.listdir('./static/gallery/')
    images = {}
    for album in album_names:
        images[album] = []
        for image_name in os.listdir('./static/gallery/' + album):
            images[album].append('gallery/' + album + '/' + image_name)
            

    return render_template('gallery.html', categories=all_categories, images=images)

@app.route('/gallery/<string:album>')
def album(album):
    all_categories = getAllCategories()

    album_names = os.listdir('./static/gallery/')
    images = []
    for img in os.listdir('./static/gallery/' + album):
        images.append('gallery/' + album + '/' + img)

    return render_template('gallery.html', categories=all_categories, albums=album_names, active=album, images=images)

@app.route('/about-us')
def about():
    all_categories = getAllCategories()
    return render_template('about.html', categories=all_categories)

@app.route('/about-us/our-story')
def story():
    all_categories = getAllCategories()
    return render_template('story.html', categories=all_categories)

@app.route('/about-us/join-us', methods=['GET', 'POST'])
def join():
    all_categories = getAllCategories()
    
    form = ContactForm()
    if form.validate_on_submit():
        name=form.name.data 
        email=form.email.data
        message=form.message.data
        msg = Message("Idea Submission by " + name, sender=email, recipients=[email, 'contact.jaynakum+mywebsite@gmail.com'])
        msg.body = message        
        mail.send(msg)
        return redirect('/about-us')
    return render_template('join.html', categories=all_categories, form=form)

@app.route('/admin')
@login_required
def admin():
    all_products = Product.query.all()
    return render_template('./admin/all-products.html', products=all_products)

@app.route('/admin/add-product', methods=['GET', 'POST'])
@login_required
def addProduct():
    form = AddProduct()
    if form.validate_on_submit():
        new_data = Product(name=form.name.data, desc=form.desc.data, img=form.img.data, category=form.category.data, onHome=form.onHome.data)
        db.session.add(new_data)
        db.session.commit()
        return redirect(url_for('home'))
    return render_template('./admin/add-product.html', form=form)

@app.route('/admin/update-product/<int:id>', methods=['GET', 'POST'])
@login_required
def updateProduct(id):
    product = Product.query.filter_by(id=id).first()
    form = AddProduct()
    form.name.data = product.name
    form.desc.data = product.desc
    form.img.data = product.img
    form.category.data = product.category
    form.onHome.data = product.onHome

    if request.method == 'POST':
        product.name = request.form['name']
        product.desc = request.form['desc']
        product.img = request.form['img']
        product.category = request.form['category']
        try:
            product.onHome = (request.form['onHome'] == 'y')
        except:
            product.onHome = False
        db.session.add(product)
        db.session.commit()
        return redirect('/admin')

    return render_template('./admin/update-product.html', form=form)

@app.route('/admin/delete-product/<int:id>', methods=['GET', 'POST'])
@login_required
def deleteProduct(id):
    product = Product.query.filter_by(id=id).first()
    db.session.delete(product)
    db.session.commit()
    return redirect('/admin')

@app.route('/admin/users')
@login_required
def allUsers():
    all_users = User.query.all()
    return render_template('./admin/all-users.html', users=all_users)

@app.route('/admin/delete-user/<int:id>', methods=['GET', 'POST'])
@login_required
def deleteUser(id):
    user = User.query.filter_by(id=id).first()
    db.session.delete(user)
    db.session.commit()
    return redirect('/admin/users')



@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()

    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data)
        new_user = User(username=form.username.data, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))
    
    all_categories = getAllCategories()
    return render_template('register.html', form=form, categories=all_categories)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        user = User.query.get(current_user.get_id())
        if user.username=='adminid ':
            return redirect(url_for('admin'))
        else:
            return redirect('/')
    else:
        form = LoginForm()
        if form.validate_on_submit():
            user = User.query.filter_by(username=form.username.data).first()
            if user:
                if bcrypt.check_password_hash(user.password, form.password.data):
                    login_user(user)
                    if user.username=='adminid':
                        return redirect(url_for('admin'))
                    else:
                        return redirect('/')
    
    all_categories = getAllCategories()
    return render_template('login.html', form=form, categories=all_categories)

@app.route('/logout', methods=['GET', 'POST'])
def logout():
    logout_user()
    return redirect(url_for('login'))

if __name__ == "__main__":
    app.run(debug=True)
